import asyncio
from multiprocessing import Process
from file_monitor import FileMonitor
from process_monitor import ProcessMonitor
from sys_monitor import SysMonitor
from websocket_client import WebSocketClient

def dataReturn(code: int, msg: str, data=None):
    return {'code': code, 'msg': msg, 'data': data}

async def send_data(ws_client, data):
    await ws_client.send_message(dataReturn(1, "Monitoring data", data))


async def monitor_sys(ws_client):
    sys_monitor = SysMonitor()

    try:
        while True:
            cpu_data = sys_monitor.cpu()
            mem_data = sys_monitor.mem()
            net_data = sys_monitor.net()
            await send_data(ws_client, {"type": "system", "cpu": cpu_data, "memory": mem_data, "network": net_data})
            await asyncio.sleep(5)  # Adjust the interval as needed
    except KeyboardInterrupt:
        pass
async def monitor_files(ws_client, paths):
    def file_callback(event_type, path):
        asyncio.run(send_data(ws_client, {"type": "file", "event": event_type, "path": path}))

    file_monitor = FileMonitor(paths, file_callback)
    file_monitor.start()

    try:
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        file_monitor.stop()

async def monitor_processes(ws_client, processes_to_monitor):
    def process_callback(event_type, pid):
        asyncio.run(send_data(ws_client, {"type": "process", "event": event_type, "pid": pid}))

    process_monitor = ProcessMonitor(process_callback, processes_to_monitor)
    process_monitor.start()

    try:
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        process_monitor.stop()
#
# async def monitor_registry(ws_client, keys_to_monitor):
#     def registry_callback(event_type, key):
#         asyncio.run(send_data(ws_client, {"type": "registry", "event": event_type, "key": key}))
#
#     registry_monitor = RegistryMonitor(keys_to_monitor, registry_callback)
#     registry_monitor.start()
#
#     try:
#         while True:
#             await asyncio.sleep(1)
#     except KeyboardInterrupt:
#         pass
#     finally:
#         registry_monitor.stop()

def start_monitoring(uri, paths, processes_to_monitor):
    ws_client = WebSocketClient(uri)

    file_process = Process(target=asyncio.run, args=(monitor_files(ws_client, paths),))
    process_monitor_process = Process(target=asyncio.run, args=(monitor_processes(ws_client, processes_to_monitor),))
    sys_process = Process(target=asyncio.run, args=(monitor_sys(ws_client),))
    # registry_monitor_process = Process(target=asyncio.run, args=(monitor_registry(ws_client, keys_to_monitor),))

    file_process.start()
    process_monitor_process.start()
    sys_process.start()
    # registry_monitor_process.start()

    file_process.join()
    process_monitor_process.join()
    sys_process.join()
    # registry_monitor_process.join()

if __name__ == "__main__":
    server_uri = "ws://192.168.100.101:8004/test/load_info"
    paths_to_monitor = ["C:\\path_to_monitor1", "C:\\path_to_monitor2"]
    processes_to_monitor = ["ssh", "telnet"]
    # keys_to_monitor = [(winreg.HKEY_CURRENT_USER, "Software\\path_to_monitor1"), (winreg.HKEY_LOCAL_MACHINE, "Software\\path_to_monitor2")]

    start_monitoring(server_uri, paths_to_monitor, processes_to_monitor)
