import asyncio
import websockets
import json

class WebSocketClient:
    def __init__(self, uri):
        self.uri = uri

    async def send_message(self, message):
        async with websockets.connect(self.uri) as websocket:
            await websocket.send(json.dumps(message))
