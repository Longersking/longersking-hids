
paths_to_monitor = ["/etc/passwd", "/etc/shadow", "/root/.bash_history", "/etc/init.d"]