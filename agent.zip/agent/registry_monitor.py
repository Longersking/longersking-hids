# import ctypes
# from ctypes import wintypes
# import winreg
#
# class RegistryMonitor:
#     def __init__(self, keys_to_monitor, callback):
#         self.keys_to_monitor = keys_to_monitor
#         self.callback = callback
#         self.running = False
#         self.change_handles = []
#
#     def start(self):
#         self.running = True
#         for hive, key in self.keys_to_monitor:
#             change_handle = self._start_monitoring(hive, key)
#             self.change_handles.append(change_handle)
#
#     def stop(self):
#         self.running = False
#         for handle in self.change_handles:
#             ctypes.windll.kernel32.CloseHandle(handle)
#         self.change_handles = []
#
#     def _start_monitoring(self, hive, key):
#         reg_handle = winreg.OpenKey(hive, key, 0, winreg.KEY_NOTIFY)
#         event = ctypes.windll.kernel32.CreateEventW(None, True, False, None)
#         ctypes.windll.advapi32.RegNotifyChangeKeyValue(
#             reg_handle, True, winreg.REG_NOTIFY_CHANGE_LAST_SET, event, True
#         )
#         thread = threading.Thread(target=self._monitor_key, args=(event, hive, key))
#         thread.start()
#         return event
#
#     def _monitor_key(self, event, hive, key):
#         while self.running:
#             ctypes.windll.kernel32.WaitForSingleObject(event, wintypes.INFINITE)
#             if not self.running:
#                 break
#             self.callback('changed', f'{hive}\\{key}')
#             ctypes.windll.kernel32.ResetEvent(event)
#         winreg.CloseKey(reg_handle)
