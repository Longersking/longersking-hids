mysql_username = "root"
mysql_password = "123456"
mysql_name = 'hids_db'